# Startup idea evaluator — full roadmap to a live website

This project turns the "Venture Dossier" tool into a real website: a frontend
anyone can visit, and a small backend that securely calls Claude to generate
the evaluation. Your Anthropic API key never touches the browser.

```
startup-evaluator/
├── index.html        ← frontend (UI, charts, forms)
├── api/
│   └── evaluate.js    ← backend serverless function (calls Anthropic API)
├── package.json
├── .env.example
└── .gitignore
```

---

## 1. How it fits together

```
Browser (index.html)
   │  user types idea, clicks "Open File"
   ▼
POST /api/evaluate  { idea: "..." }
   │
   ▼
Serverless function (api/evaluate.js)
   │  adds ANTHROPIC_API_KEY from server environment
   │  calls https://api.anthropic.com/v1/messages
   ▼
Claude returns JSON evaluation
   │
   ▼
Function returns JSON to browser
   │
   ▼
Browser renders charts (Chart.js) and report sections
```

The key idea: **the API key lives only on the server**, set as an environment
variable. The frontend never sees it, so it's safe to make the site public.

---

## 2. Prerequisites

- A free [GitHub](https://github.com) account (to hold the code)
- A free [Vercel](https://vercel.com) account (to host it) — Netlify or
  Cloudflare Pages work too, with minor changes noted in step 6
- An Anthropic API key from [console.anthropic.com](https://console.anthropic.com)
  → API Keys → Create Key
- Node.js installed locally (only needed for local testing)

---

## 3. Get the code onto your machine

1. Create a new folder and place `index.html`, the `api/` folder,
   `package.json`, `.gitignore`, and `.env.example` inside it exactly as
   shown in the tree above.
2. Initialize git and push to a new GitHub repo:

```bash
cd startup-evaluator
git init
git add .
git commit -m "Initial commit: startup idea evaluator"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/startup-evaluator.git
git push -u origin main
```

---

## 4. Test it locally (optional but recommended)

1. Install the Vercel CLI:

```bash
npm install -g vercel
```

2. Copy `.env.example` to `.env` and paste in your real key:

```bash
cp .env.example .env
```

```
ANTHROPIC_API_KEY=sk-ant-xxxxxxxxxxxxxxxx
```

3. Run the dev server, which serves both the static frontend and the
   serverless function together:

```bash
vercel dev
```

4. Open `http://localhost:3000`, enter an idea, click "Open File". The
   request goes to `/api/evaluate` on your machine, which calls Anthropic
   using the key from `.env`.

---

## 5. Deploy to Vercel (the easy path)

1. Go to [vercel.com/new](https://vercel.com/new) and import your GitHub
   repository.
2. Vercel auto-detects the `api/` folder as serverless functions and
   `index.html` as a static file — no build configuration needed.
3. Before deploying, add your environment variable:
   - In the import screen (or later under **Settings → Environment
     Variables**), add:
     - Name: `ANTHROPIC_API_KEY`
     - Value: your real key
     - Environment: Production (and Preview if you want preview deploys to work)
4. Click **Deploy**. After ~30 seconds you'll get a live URL like
   `https://startup-evaluator-yourname.vercel.app`.
5. Visit it — the live site now calls your backend, which calls Claude.

Every time you `git push` to `main`, Vercel automatically redeploys.

---

## 6. Alternative hosts

**Netlify**
- Same structure, but serverless functions live in `netlify/functions/`
  instead of `api/`, and you'd rename `evaluate.js` to export a handler in
  Netlify's format (`exports.handler = async (event) => {...}`).
- Set the env var under **Site settings → Environment variables**.

**Cloudflare Pages**
- Functions live in a `functions/` directory using the Pages Functions
  format (`export async function onRequestPost(context) {...}`).
- Set the env var under **Settings → Environment variables**.

Vercel requires the least code change from what's provided here, so it's the
recommended starting point.

---

## 7. Add a custom domain

1. Buy a domain from any registrar (Namecheap, Google Domains, etc.).
2. In your Vercel project, go to **Settings → Domains**, add your domain.
3. Vercel shows you DNS records (usually a CNAME or A record) — add those at
   your registrar.
4. Wait for DNS propagation (a few minutes to a few hours); Vercel issues a
   free HTTPS certificate automatically.

---

## 8. Cost and usage controls

Every "Open File" click makes one Claude API call, billed per token on your
Anthropic account.

- **Set a budget alert**: in the Anthropic console, set a monthly spend limit
  or alert so you're notified before costs grow unexpectedly.
- **Rate limit the endpoint** so one visitor can't spam requests. A simple
  approach inside `api/evaluate.js`:
  - Track request counts per IP in a small store (Vercel KV, Upstash Redis,
    or even an in-memory map for low traffic) and reject after, say, 5
    requests per hour.
- **Cap input length** — already done in `evaluate.js` (`.slice(0, 1000)`) to
  keep prompts (and cost) bounded.
- **Cache repeated ideas**: if the same idea text is submitted again, return
  the cached result instead of calling the API again (store in Vercel KV or
  a database keyed by a hash of the idea text).

---

## 9. Security checklist

- [ ] `.env` is in `.gitignore` and never committed
- [ ] `ANTHROPIC_API_KEY` is set only as a server-side environment variable
- [ ] The frontend calls `/api/evaluate`, never `api.anthropic.com` directly
- [ ] Input length is capped server-side
- [ ] (Optional) Rate limiting is in place if you expect public traffic
- [ ] (Optional) A budget alert is configured in the Anthropic console

---

## 10. Optional enhancements

Roughly in order of effort:

1. **Loading polish**: swap the plain "Reviewing market data…" text for a
   progress animation or skeleton charts.
2. **Shareable results**: after evaluation, generate a unique URL
   (`/r/<id>`) that re-displays a saved result — requires a small database
   (Vercel Postgres, Supabase, or similar) to store results by ID.
3. **Export to PDF**: add a "Download report" button using a library like
   `html2pdf.js` (loadable from cdnjs) to export the rendered dossier.
4. **History**: store each user's past evaluations in `localStorage` (client
   only, no backend change) so they can revisit prior ideas.
5. **Authentication**: add login (e.g. via Clerk, Auth0, or NextAuth if you
   migrate to a Next.js app) if you want to limit usage per user or save
   evaluations to accounts.
6. **Streaming responses**: switch the Anthropic call to streaming
   (`stream: true`) and update the frontend to show the report sections as
   they arrive, rather than waiting for the full response.
7. **Migrate to a framework**: if the project grows, moving `index.html` into
   a Next.js or Vite + React app gives you routing, component structure, and
   easier state management — the `api/evaluate.js` function ports over with
   almost no changes.

---

## 11. Quick reference — file roles

| File | Role |
|---|---|
| `index.html` | Entire frontend: form, charts (Chart.js), result rendering |
| `api/evaluate.js` | Serverless function: builds the prompt, calls Anthropic, returns parsed JSON |
| `.env` (not committed) | Holds `ANTHROPIC_API_KEY` locally |
| `package.json` | Project metadata and dev script |
| `.gitignore` | Keeps secrets and local files out of git |
