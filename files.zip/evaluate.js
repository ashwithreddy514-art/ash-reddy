// /api/evaluate.js
// Vercel serverless function (Node runtime).
// Keeps the Anthropic API key on the server, never exposed to the browser.

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const { idea } = req.body || {};
  if (!idea || typeof idea !== 'string' || !idea.trim()) {
    return res.status(400).json({ error: 'Missing "idea" in request body' });
  }

  // Basic guardrails: cap input length to keep prompts (and costs) bounded
  const trimmedIdea = idea.trim().slice(0, 1000);

  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) {
    return res.status(500).json({ error: 'Server is missing ANTHROPIC_API_KEY' });
  }

  const prompt = buildPrompt(trimmedIdea);

  try {
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': apiKey,
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify({
        model: 'claude-sonnet-4-6',
        max_tokens: 4000,
        messages: [{ role: 'user', content: prompt }],
      }),
    });

    if (!response.ok) {
      const errText = await response.text();
      return res.status(response.status).json({ error: 'Anthropic API error', details: errText });
    }

    const data = await response.json();
    const text = (data.content || [])
      .map((b) => (b.type === 'text' ? b.text : ''))
      .join('');

    const clean = text.replace(/```json|```/g, '').trim();
    let parsed;
    try {
      parsed = JSON.parse(clean);
    } catch (e) {
      return res.status(502).json({ error: 'Model did not return valid JSON', raw: text });
    }

    return res.status(200).json(parsed);
  } catch (e) {
    return res.status(500).json({ error: 'Request to Anthropic failed', details: String(e) });
  }
}

function buildPrompt(idea) {
  return `You are a pragmatic, experienced startup analyst conducting due diligence. Evaluate the following startup idea and respond with ONLY a valid JSON object (no markdown code fences, no preamble, no commentary) matching exactly this schema:

{
  "ideaName": "short punchy name for the idea, max 6 words",
  "oneLiner": "one sentence pitch, max 20 words",
  "verdict": {
    "score": number from 0 to 100,
    "label": "one of: High Potential, Promising, Mixed Signals, Needs Rework, High Risk",
    "summary": "2-3 sentence honest summary of the overall assessment"
  },
  "scores": {
    "marketOpportunity": number 0-10,
    "feasibility": number 0-10,
    "differentiation": number 0-10,
    "monetization": number 0-10,
    "scalability": number 0-10,
    "timing": number 0-10
  },
  "market": {
    "tam": number (Total Addressable Market in raw USD, realistic estimate),
    "sam": number (Serviceable Addressable Market in raw USD),
    "som": number (Serviceable Obtainable Market in raw USD, realistic 5yr capture),
    "description": "2-3 sentences explaining the market sizing reasoning"
  },
  "scalingMetric": "label for the metric used in scaling projection, e.g. Annual Recurring Revenue (USD)",
  "scaling": [
    {"year": "Year 1", "conservative": number, "moderate": number, "aggressive": number},
    {"year": "Year 2", "conservative": number, "moderate": number, "aggressive": number},
    {"year": "Year 3", "conservative": number, "moderate": number, "aggressive": number},
    {"year": "Year 4", "conservative": number, "moderate": number, "aggressive": number},
    {"year": "Year 5", "conservative": number, "moderate": number, "aggressive": number}
  ],
  "targetMarket": "2-3 sentences describing the ideal early customer segment",
  "businessModel": "2-3 sentences describing how this makes money",
  "competitors": [
    {"name": "competitor or alternative name", "note": "one sentence on their position"}
  ],
  "swot": {
    "strengths": ["3 to 4 short bullet points"],
    "weaknesses": ["3 to 4 short bullet points"],
    "opportunities": ["3 to 4 short bullet points"],
    "threats": ["3 to 4 short bullet points"]
  },
  "risks": ["3 to 5 short bullet points on key risks"],
  "nextSteps": ["3 to 5 short, concrete, actionable next steps to validate this idea"]
}

Provide 3 to 5 competitors. Be realistic and specific with numbers, grounded in real-world market knowledge. Do not be overly optimistic — give an honest assessment including weaknesses.

Startup idea to evaluate:
"""${idea}"""

Respond with ONLY the JSON object described above.`;
}
